package com.Prolifics;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import static org.testng.Assert.assertTrue;

import java.util.List;
import java.util.Random;
import java.util.concurrent.TimeUnit;
public class Home {
	private static WebElement element = null;
	public static WebDriver driver;



	void prolificsBlog(WebDriver driver) {
		this.driver = driver;
	}

	@FindBy(xpath="(//a[contains(text(),'Insights')])[2]")
	WebElement Insights;

	@FindBy(xpath="//li[@data-id=\"5043\"]//a")
	WebElement Blog;

	@FindBy(xpath="//option[@value='634']")
	WebElement Banking;

	@FindBy(xpath="//button[@id='edit-submit-blog']")
	WebElement Search;


	public Home(WebDriver driver) {

		this.driver = driver;

		PageFactory.initElements(driver, this);
	}
	public void register() throws InterruptedException {

		Thread.sleep(5000);

		Actions action = new Actions(driver);
		action.moveToElement(Insights).build().perform();
		Blog.click();
		String URL = driver.getCurrentUrl();
		Assert.assertEquals(URL, "https://www.prolifics.com/blog" );
		System.out.println("Blog is accessed");

		Banking.click();
		Thread.sleep(5000);
		Search.click();
		
		List<WebElement> list = driver.findElements(By.xpath("//div[@class='view-content']//div[@class='views-field views-field-title']//a"));
		int size = list.size();
		
		System.out.println("Number of blogs are "+size);

		for(int i=0;i<=11;i++) {
			driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
			list = driver.findElements(By.xpath("//div[@class='view-content']//div[@class='views-field views-field-title']//a"));
			list.get(i).click();
			Thread.sleep(5000);
			driver.navigate().back();
		}
	

		driver.close();

	}
}

