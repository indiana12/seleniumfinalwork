package com.SelExcel;

public class SeleniumWrite {
	public static final String URL = "http://newtours.demoaut.com";
	public static final String userName = "testuser_1";
	public static final String Password = "Test@123";
	public static final String first = "C:\\Users\\Plucky\\Desktop\\jars and files\\selenium\\Excel files";
	public static final String second = "Book1.xlsx";
}